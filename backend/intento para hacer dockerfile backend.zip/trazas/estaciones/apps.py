from django.apps import AppConfig


class EstacionesConfig(AppConfig):
    name = 'estaciones'
