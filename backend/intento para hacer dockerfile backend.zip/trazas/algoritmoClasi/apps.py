from django.apps import AppConfig


class AlgoritmoclasiConfig(AppConfig):
    name = 'algoritmoClasi'
