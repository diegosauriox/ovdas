from django.apps import AppConfig


class ApibackendConfig(AppConfig):
    name = 'apibackend'
