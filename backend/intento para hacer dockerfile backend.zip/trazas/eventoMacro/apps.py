from django.apps import AppConfig


class EventomacroConfig(AppConfig):
    name = 'eventoMacro'
