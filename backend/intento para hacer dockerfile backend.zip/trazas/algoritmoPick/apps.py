from django.apps import AppConfig


class AlgoritmopickConfig(AppConfig):
    name = 'algoritmoPick'
