from django.apps import AppConfig


class WavesConfig(AppConfig):
    name = 'waves'
