from django.apps import AppConfig


class EventolocaliConfig(AppConfig):
    name = 'eventoLocali'
