from django.apps import AppConfig


class IdentificacionConfig(AppConfig):
    name = 'identificacion'
