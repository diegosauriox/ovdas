from django.apps import AppConfig


class AvistamientoregistroConfig(AppConfig):
    name = 'avistamientoRegistro'
