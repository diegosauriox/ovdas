from django.apps import AppConfig


class AlgoritmodetecConfig(AppConfig):
    name = 'algoritmoDetec'
