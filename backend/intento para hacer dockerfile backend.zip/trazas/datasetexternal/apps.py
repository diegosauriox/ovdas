from django.apps import AppConfig


class DatasetexternalConfig(AppConfig):
    name = 'datasetexternal'
